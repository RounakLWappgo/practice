import React from 'react'

export default function Body() {
    return (
        <div>
            this is body
        </div>
    )
}
